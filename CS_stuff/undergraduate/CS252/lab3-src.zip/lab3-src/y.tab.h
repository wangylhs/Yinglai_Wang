
typedef union
#ifdef __cplusplus
	YYSTYPE
#endif
	{
		char   *string_val;
	} YYSTYPE;
extern YYSTYPE yylval;
# define WORD 257
# define NOTOKEN 258
# define GREAT 259
# define NEWLINE 260
# define LESS 261
# define PIPE 262
# define BACKGROUND 263
# define APPEND 264
# define REDIRECT 265
# define APPEND_REDIRECT 266

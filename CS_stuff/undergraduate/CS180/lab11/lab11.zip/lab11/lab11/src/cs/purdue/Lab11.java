package cs.purdue;

public class Lab11 {
	
	static int x,y,width,height;
	
	//used for grading to make sure current application is by students demoing the application
	static String user_name = "user_name";
	
	public static void main(String[] args){


	}

}

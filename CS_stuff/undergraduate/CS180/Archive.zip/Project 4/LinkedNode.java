
public class LinkedNode<E> {

	public E item;
	public LinkedNode next;
}

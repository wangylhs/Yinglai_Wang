echo $(ls -xS docs/*.txt) | xargs ./omp

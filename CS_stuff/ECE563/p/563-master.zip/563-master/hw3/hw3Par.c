#include <omp.h>
#include <stdio.h>
#include <stdlib.h>

void doWork(int t) {
   sleep(t);
}

int main (int argc, char *argv[]) {
   
}


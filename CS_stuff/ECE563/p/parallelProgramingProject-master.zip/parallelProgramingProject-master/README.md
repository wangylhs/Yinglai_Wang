parallelProgramingProject
=========================

《高级并行程序设计》课程报告代码附录
----------------------------------- 
目录结构：<br>
cannon/ 		cannon算法的串行、MPI、OpenMP版本实现<br>
computing/		实验测试过程中用到的测试数据生成程序和加速比、效率计算程序<br>
quickSort/		quickSort算法的串行、MPI、OpenMP版本实现<br>
Gauss/			Gauss消元解方程组算法的串行、MPI、OpenMP版本实现<br>
bfs/			宽度优先搜索算法的串行、MPI、OpenMP版本实现<br>